# Weekly GTM review | 2025-02-21

**Synthetic demo data**

16 target accounts. 3 deduplicated meetings observed through the snapshot.

## Stage movement

- A03 moved from Meeting to Proposal.
- A11 moved from Follow-up to Meeting.
- A14 moved from Proposal to Closed.

## Stalled accounts

- A04 remains in Follow-up.

## Overdue follow-ups

- A02 · 2025-02-20 · Send discovery times
- A04 · 2025-02-19 · Send a question about review workflow
- A16 · 2025-02-20 · Verify delivery details
